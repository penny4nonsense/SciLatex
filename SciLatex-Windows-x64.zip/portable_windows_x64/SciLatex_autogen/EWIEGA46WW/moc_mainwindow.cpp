/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN10MainWindowE_t {};
} // unnamed namespace


#ifdef QT_MOC_HAS_STRINGDATA
static constexpr auto qt_meta_stringdata_ZN10MainWindowE = QtMocHelpers::stringData(
    "MainWindow",
    "newFile",
    "",
    "openFile",
    "closeFile",
    "saveFile",
    "saveFileAs",
    "compile",
    "importFile",
    "exportFile",
    "preview",
    "printFile",
    "preferences",
    "recentFiles",
    "exitApp",
    "undo",
    "redo",
    "cut",
    "copy",
    "paste",
    "deleteContent",
    "selectAll",
    "findText",
    "replaceText",
    "spellCheck",
    "insertMathText",
    "insertFraction",
    "insertRadical",
    "insertSuperscript",
    "insertSubscript",
    "insertDisplay",
    "insertOperator",
    "insertBracket",
    "insertMatrix",
    "insertMathName",
    "insertBinomial",
    "insertLabel",
    "insertDecoration",
    "insertFontStyle",
    "insertSpacing",
    "insertTable",
    "insertNote",
    "insertFormula",
    "insertHyperlink",
    "insertMarker",
    "insertHtmlField",
    "setFontSize",
    "points",
    "customFontSize",
    "zoomIn",
    "zoomOut",
    "resetZoom",
    "refreshView",
    "evaluate",
    "evaluateNumerically",
    "simplify",
    "combine",
    "factor",
    "expand",
    "rewrite",
    "checkEquality",
    "solve",
    "plot2D",
    "plot3D",
    "computeSettings",
    "onFindPrevious",
    "onFindNext",
    "onReplacePrevious",
    "onReplaceNext",
    "onReplaceAll"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA

Q_CONSTINIT static const uint qt_meta_data_ZN10MainWindowE[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      67,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  416,    2, 0x08,    1 /* Private */,
       3,    0,  417,    2, 0x08,    2 /* Private */,
       4,    0,  418,    2, 0x08,    3 /* Private */,
       5,    0,  419,    2, 0x08,    4 /* Private */,
       6,    0,  420,    2, 0x08,    5 /* Private */,
       7,    0,  421,    2, 0x08,    6 /* Private */,
       8,    0,  422,    2, 0x08,    7 /* Private */,
       9,    0,  423,    2, 0x08,    8 /* Private */,
      10,    0,  424,    2, 0x08,    9 /* Private */,
      11,    0,  425,    2, 0x08,   10 /* Private */,
      12,    0,  426,    2, 0x08,   11 /* Private */,
      13,    0,  427,    2, 0x08,   12 /* Private */,
      14,    0,  428,    2, 0x08,   13 /* Private */,
      15,    0,  429,    2, 0x08,   14 /* Private */,
      16,    0,  430,    2, 0x08,   15 /* Private */,
      17,    0,  431,    2, 0x08,   16 /* Private */,
      18,    0,  432,    2, 0x08,   17 /* Private */,
      19,    0,  433,    2, 0x08,   18 /* Private */,
      20,    0,  434,    2, 0x08,   19 /* Private */,
      21,    0,  435,    2, 0x08,   20 /* Private */,
      22,    0,  436,    2, 0x08,   21 /* Private */,
      23,    0,  437,    2, 0x08,   22 /* Private */,
      24,    0,  438,    2, 0x08,   23 /* Private */,
      25,    0,  439,    2, 0x08,   24 /* Private */,
      26,    0,  440,    2, 0x08,   25 /* Private */,
      27,    0,  441,    2, 0x08,   26 /* Private */,
      28,    0,  442,    2, 0x08,   27 /* Private */,
      29,    0,  443,    2, 0x08,   28 /* Private */,
      30,    0,  444,    2, 0x08,   29 /* Private */,
      31,    0,  445,    2, 0x08,   30 /* Private */,
      32,    0,  446,    2, 0x08,   31 /* Private */,
      33,    0,  447,    2, 0x08,   32 /* Private */,
      34,    0,  448,    2, 0x08,   33 /* Private */,
      35,    0,  449,    2, 0x08,   34 /* Private */,
      36,    0,  450,    2, 0x08,   35 /* Private */,
      37,    0,  451,    2, 0x08,   36 /* Private */,
      38,    0,  452,    2, 0x08,   37 /* Private */,
      39,    0,  453,    2, 0x08,   38 /* Private */,
      40,    0,  454,    2, 0x08,   39 /* Private */,
      41,    0,  455,    2, 0x08,   40 /* Private */,
      42,    0,  456,    2, 0x08,   41 /* Private */,
      43,    0,  457,    2, 0x08,   42 /* Private */,
      44,    0,  458,    2, 0x08,   43 /* Private */,
      45,    0,  459,    2, 0x08,   44 /* Private */,
      46,    1,  460,    2, 0x08,   45 /* Private */,
      48,    0,  463,    2, 0x08,   47 /* Private */,
      49,    0,  464,    2, 0x08,   48 /* Private */,
      50,    0,  465,    2, 0x08,   49 /* Private */,
      51,    0,  466,    2, 0x08,   50 /* Private */,
      52,    0,  467,    2, 0x08,   51 /* Private */,
      53,    0,  468,    2, 0x08,   52 /* Private */,
      54,    0,  469,    2, 0x08,   53 /* Private */,
      55,    0,  470,    2, 0x08,   54 /* Private */,
      56,    0,  471,    2, 0x08,   55 /* Private */,
      57,    0,  472,    2, 0x08,   56 /* Private */,
      58,    0,  473,    2, 0x08,   57 /* Private */,
      59,    0,  474,    2, 0x08,   58 /* Private */,
      60,    0,  475,    2, 0x08,   59 /* Private */,
      61,    0,  476,    2, 0x08,   60 /* Private */,
      62,    0,  477,    2, 0x08,   61 /* Private */,
      63,    0,  478,    2, 0x08,   62 /* Private */,
      64,    0,  479,    2, 0x08,   63 /* Private */,
      65,    0,  480,    2, 0x08,   64 /* Private */,
      66,    0,  481,    2, 0x08,   65 /* Private */,
      67,    0,  482,    2, 0x08,   66 /* Private */,
      68,    0,  483,    2, 0x08,   67 /* Private */,
      69,    0,  484,    2, 0x08,   68 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   47,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_ZN10MainWindowE.offsetsAndSizes,
    qt_meta_data_ZN10MainWindowE,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_tag_ZN10MainWindowE_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'newFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'openFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'closeFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveFileAs'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'compile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'importFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exportFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'preview'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'printFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'preferences'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recentFiles'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'exitApp'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'undo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'redo'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'copy'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'paste'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'deleteContent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'findText'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'replaceText'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'spellCheck'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertMathText'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertFraction'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertRadical'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertSuperscript'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertSubscript'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertDisplay'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertOperator'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertBracket'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertMatrix'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertMathName'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertBinomial'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertLabel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertDecoration'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertFontStyle'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertSpacing'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertTable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertNote'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertFormula'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertHyperlink'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertMarker'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'insertHtmlField'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setFontSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'customFontSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomIn'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'zoomOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'resetZoom'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'refreshView'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'evaluate'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'evaluateNumerically'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'simplify'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'combine'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'factor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'expand'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rewrite'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'checkEquality'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'solve'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'plot2D'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'plot3D'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'computeSettings'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onFindPrevious'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onFindNext'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onReplacePrevious'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onReplaceNext'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onReplaceAll'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<MainWindow *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->newFile(); break;
        case 1: _t->openFile(); break;
        case 2: _t->closeFile(); break;
        case 3: _t->saveFile(); break;
        case 4: _t->saveFileAs(); break;
        case 5: _t->compile(); break;
        case 6: _t->importFile(); break;
        case 7: _t->exportFile(); break;
        case 8: _t->preview(); break;
        case 9: _t->printFile(); break;
        case 10: _t->preferences(); break;
        case 11: _t->recentFiles(); break;
        case 12: _t->exitApp(); break;
        case 13: _t->undo(); break;
        case 14: _t->redo(); break;
        case 15: _t->cut(); break;
        case 16: _t->copy(); break;
        case 17: _t->paste(); break;
        case 18: _t->deleteContent(); break;
        case 19: _t->selectAll(); break;
        case 20: _t->findText(); break;
        case 21: _t->replaceText(); break;
        case 22: _t->spellCheck(); break;
        case 23: _t->insertMathText(); break;
        case 24: _t->insertFraction(); break;
        case 25: _t->insertRadical(); break;
        case 26: _t->insertSuperscript(); break;
        case 27: _t->insertSubscript(); break;
        case 28: _t->insertDisplay(); break;
        case 29: _t->insertOperator(); break;
        case 30: _t->insertBracket(); break;
        case 31: _t->insertMatrix(); break;
        case 32: _t->insertMathName(); break;
        case 33: _t->insertBinomial(); break;
        case 34: _t->insertLabel(); break;
        case 35: _t->insertDecoration(); break;
        case 36: _t->insertFontStyle(); break;
        case 37: _t->insertSpacing(); break;
        case 38: _t->insertTable(); break;
        case 39: _t->insertNote(); break;
        case 40: _t->insertFormula(); break;
        case 41: _t->insertHyperlink(); break;
        case 42: _t->insertMarker(); break;
        case 43: _t->insertHtmlField(); break;
        case 44: _t->setFontSize((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 45: _t->customFontSize(); break;
        case 46: _t->zoomIn(); break;
        case 47: _t->zoomOut(); break;
        case 48: _t->resetZoom(); break;
        case 49: _t->refreshView(); break;
        case 50: _t->evaluate(); break;
        case 51: _t->evaluateNumerically(); break;
        case 52: _t->simplify(); break;
        case 53: _t->combine(); break;
        case 54: _t->factor(); break;
        case 55: _t->expand(); break;
        case 56: _t->rewrite(); break;
        case 57: _t->checkEquality(); break;
        case 58: _t->solve(); break;
        case 59: _t->plot2D(); break;
        case 60: _t->plot3D(); break;
        case 61: _t->computeSettings(); break;
        case 62: _t->onFindPrevious(); break;
        case 63: _t->onFindNext(); break;
        case 64: _t->onReplacePrevious(); break;
        case 65: _t->onReplaceNext(); break;
        case 66: _t->onReplaceAll(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ZN10MainWindowE.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 67)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 67;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 67)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 67;
    }
    return _id;
}
QT_WARNING_POP
